//------------------------------------------------------------------------------
//
// File Name:	BehaviorSpaceship.h
// Author(s):	Justin Klass (justin.klass)
// Project:		Project 4
// Course:		CS230S22
//
// Copyright � 2022 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

#include "stdafx.h"
#include "Behavior.h"
#include "GameObject.h"
#include "BehaviorBullet.h"

typedef enum
{
	cBulletInvalid = -1,

	cBulletIdle

} behaviorBulletStates;

static void BehaviorBulletUpdateLifeTimer(BehaviorPtr behavior, float dt);


BehaviorPtr BehaviorBulletCreate(void)
{
	BehaviorPtr newBullet = calloc(1, sizeof(Behavior));

	if (newBullet != NULL)
	{
		newBullet->stateCurr = cBulletInvalid;
		newBullet->stateNext = cBulletInvalid;

		newBullet->onInit = &BehaviorBulletInit;
		newBullet->onUpdate = &BehaviorBulletUpdate;
		newBullet->onExit = &BehaviorBulletExit;

		return newBullet;
	}
	else
	{
		return NULL;
	}
}

void BehaviorBulletInit(BehaviorPtr behavior)
{
	UNREFERENCED_PARAMETER(behavior);
}

void BehaviorBulletUpdate(BehaviorPtr behavior, float dt)
{
	switch(behavior->stateCurr)
	{
		case cBulletIdle:
			BehaviorBulletUpdateLifeTimer(behavior, dt);
			break;
	}
}

void BehaviorBulletExit(BehaviorPtr behavior)
{
	UNREFERENCED_PARAMETER(behavior);
}

void BehaviorBulletUpdateLifeTimer(BehaviorPtr behavior, float dt)
{
	if (behavior->timer > 0)
	{
		behavior->timer -= dt;
		if (behavior->timer <= 0)
		{
			GameObjectDestroy(behavior->parent);
		}
	}
}